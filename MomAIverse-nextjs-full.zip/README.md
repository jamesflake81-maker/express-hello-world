
# MomAIverse (Next.js + Tailwind)

## 🚀 Local Development
```bash
npm install
npm run dev
# visit http://localhost:3000
```

## 🌐 Deploy to Vercel
1. Go to https://vercel.com
2. Import or upload this folder
3. Vercel auto-detects Next.js and deploys

## 🛠 Tech Stack
- Next.js 14
- TailwindCSS 3
- React 18
