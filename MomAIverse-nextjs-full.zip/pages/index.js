
import Head from 'next/head';

export default function Home() {
  return (
    <>
      <Head>
        <title>MomAIverse — AI Income for Moms</title>
        <meta name='description' content='Earn from home using AI systems built for moms.' />
      </Head>
      <main className='min-h-screen bg-gradient-to-br from-pink-400 to-purple-500 flex flex-col items-center justify-center text-white'>
        <h1 className='text-5xl font-bold mb-4'>Welcome to MomAIverse</h1>
        <p className='max-w-xl text-center text-lg mb-8'>
          Learn how thousands of moms are using AI to create freedom-based income systems — no experience required.
        </p>
        <a href='#' className='bg-white text-pink-600 px-6 py-3 rounded-full font-semibold shadow-lg hover:bg-gray-200'>
          Join Free Waitlist
        </a>
      </main>
    </>
  )
}
